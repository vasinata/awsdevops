﻿INSERT INTO hugelySeldom.dbo.chartCache(cacheKey,imageBytes)
VALUES(@cacheKey,@chartImage);