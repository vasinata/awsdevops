﻿SELECT imageBytes
FROM hugelySeldom.dbo.chartCache
WHERE cacheKey = @cacheKey